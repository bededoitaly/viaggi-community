<?php
/*
Plugin Name: Viaggi & Community LITE
Description: CSV admin + Liste, Form Pilota/Passeggero (ripetibili), Ricerca AJAX, Scheda Viaggio ricca, Super Mappa, Avvisi audio/video, Stampa/PDF.
Version: 1.4.1
Author: ChatGPT
*/
if (!defined('ABSPATH')) exit;

define('VCL_VER','1.4.1');
define('VCL_PATH', plugin_dir_path(__FILE__));
define('VCL_URL', plugin_dir_url(__FILE__));

require_once VCL_PATH.'includes/class-cpt.php';
require_once VCL_PATH.'includes/class-admin.php';
require_once VCL_PATH.'includes/class-search.php';
require_once VCL_PATH.'includes/class-api.php';
require_once VCL_PATH.'includes/class-shortcodes.php';
require_once VCL_PATH.'includes/class-pdf.php';

if (file_exists(VCL_PATH.'includes/class-notify.php')) {
  require_once VCL_PATH.'includes/class-notify.php';
} else {
  if (!class_exists('VCL_Notify')) {
    class VCL_Notify { public static function push(){ wp_send_json_error(); } public static function pull(){ wp_send_json_success(array()); } }
  }
}

function vcl_enqueue_shared_data(){
  $tree  = get_option('vcl_tree', array());
  $lists = array(
    'categorie' => get_option('vcl_list_categorie', array()),
    'veicoli'   => get_option('vcl_list_veicoli', array()),
    'fuel'      => get_option('vcl_list_fuel', array()),
    'ruoli'     => get_option('vcl_list_ruoli', array()),
    'quando'    => get_option('vcl_list_quando', array())
  );
  wp_register_script('vcl-shared', '', array(), VCL_VER, true);
  wp_enqueue_script('vcl-shared');
  wp_localize_script('vcl-shared', 'VCL_DATA', array(
    'ajax' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('vcl_nonce'),
    'tree'  => $tree,
    'categorie' => $lists['categorie'],
    'veicoli'   => $lists['veicoli'],
    'fuel'      => $lists['fuel'],
    'ruoli'     => $lists['ruoli'],
    'quando'    => $lists['quando']
  ));
}
function vcl_enqueue_front_assets(){
  wp_enqueue_style('vcl-style', VCL_URL.'assets/css/style.css', array(), VCL_VER);
  wp_register_style('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4');
  wp_register_script('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
  wp_enqueue_style('leaflet'); wp_enqueue_script('leaflet');
  wp_enqueue_script('vcl-map', VCL_URL.'assets/js/map.js', array('jquery','leaflet'), VCL_VER, true);
  wp_enqueue_script('vcl-alerts', VCL_URL.'assets/js/alerts.js', array('jquery'), VCL_VER, true);
  wp_enqueue_script('vcl-search', VCL_URL.'assets/js/search.js', array('jquery','leaflet','vcl-map','vcl-shared'), VCL_VER, true);
  wp_enqueue_script('vcl-scheda', VCL_URL.'assets/js/scheda.js', array('jquery','leaflet','vcl-map','vcl-shared'), VCL_VER, true);
  wp_localize_script('vcl-alerts', 'VCL_ALERT', array(
    'ajax' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('vcl_nonce'),
    'success_sound' => esc_url_raw(get_option('vcl_success_sound', VCL_URL.'assets/audio/success.mp3')),
    'sound_interest' => esc_url_raw(get_option('vcl_interest_sound', VCL_URL.'assets/audio/success.mp3')),
    'sound_urgent'   => esc_url_raw(get_option('vcl_urgent_sound', VCL_URL.'assets/audio/success.mp3')),
    'alert_video'    => esc_url_raw(get_option('vcl_alert_video', '')),
    'landing'        => esc_url_raw(get_option('vcl_landing','https://dammiunpassaggio.it/dove-ti-porto'))
  ));
  vcl_enqueue_shared_data();
}
add_filter('the_content', function($c){
  $tags = array('vc_form_pilota','vc_form_passeggero','vc_ricerca_viaggi','vc_report_viaggio','vc_scheda_viaggio',
                'vc_select_veicolo','vc_select_alimentazione','vc_select_ruolo','vc_select_categoria','vc_select_quando',
                'vc_cascata_localita','vc_options_list','vc_btn_interesse','vc_btn_urgente','vc_alert_listener','vc_super_mappa');
  foreach($tags as $t){ if (has_shortcode($c, $t)) { vcl_enqueue_front_assets(); break; } }
  return $c;
}, 0);

add_action('wp_ajax_vcl_notify', ['VCL_Notify','push']);
add_action('wp_ajax_nopriv_vcl_notify', ['VCL_Notify','push']);
add_action('wp_ajax_vcl_pull_notify', ['VCL_Notify','pull']);
add_action('wp_ajax_nopriv_vcl_pull_notify', ['VCL_Notify','pull']);
add_action('wp_ajax_vcl_search', ['VCL_Search','ajax']);
add_action('wp_ajax_nopriv_vcl_search', ['VCL_Search','ajax']);
add_action('wp_ajax_vcl_save_pilota', ['VCL_API','save_pilota']);
add_action('wp_ajax_nopriv_vcl_save_pilota', ['VCL_API','save_pilota']);
add_action('wp_ajax_vcl_save_passeggero', ['VCL_API','save_passegero_proxy']);
add_action('wp_ajax_nopriv_vcl_save_passeggero', ['VCL_API','save_passegero_proxy']);
