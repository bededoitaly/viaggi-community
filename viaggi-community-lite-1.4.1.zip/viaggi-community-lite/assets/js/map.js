(function($){
  function fill($s,a,p){ $s.empty().append($('<option>').val('').text(p||'—')); (a||[]).forEach(v=>$s.append($('<option>').val(v).text(v))); }
  function bindCascade(root){
    var t=(window.VCL_DATA||{}).tree||{}; var $r=$(root).find('select[name$="_reg"]'), $p=$(root).find('select[name$="_prov"]'), $c=$(root).find('select[name$="_com"]');
    function onR(){ var reg=$r.val(); var pv=reg&&t[reg]?Object.keys(t[reg]).sort():[]; fill($p,pv,'Provincia'); fill($c,[],'Comune'); }
    function onP(){ var reg=$r.val(), pr=$p.val(); var cm=(reg&&pr&&t[reg]&&t[reg][pr])?[].concat(t[reg][pr]).sort():[]; fill($c,cm,'Comune'); }
    fill($r,Object.keys(t).sort(),'Regione'); $r.on('change',onR); $p.on('change',onP);
  }
  function geocodeQuery(q){ var url='https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=it&q='+encodeURIComponent(q);
    return fetch(url,{headers:{'Accept':'application/json'}}).then(r=>r.json()).then(a=>{ if(a&&a[0]) return {lat:parseFloat(a[0].lat),lng:parseFloat(a[0].lon)}; return null; }).catch(()=>null); }
  function buildQuery(sel){ var root=sel.closest('.cascade'); if(!root) return ''; var s=root.querySelectorAll('select'); if(!s||s.length<3) return ''; var reg=s[0].value.trim(),prov=s[1].value.trim(),com=s[2].value.trim(); return [com,prov,reg,'Italia'].filter(Boolean).join(', '); }
  function setHidden(form,which,ll){ if(!form||!ll) return; if(which==='start'){ form.querySelector('input[name="lat"]').value=(ll.lat||''); form.querySelector('input[name="lng"]').value=(ll.lng||''); } else { form.querySelector('input[name="lat_arr"]').value=(ll.lat||''); form.querySelector('input[name="lng_arr"]').value=(ll.lng||''); } }
  function initDual(el){
    if(!window.L) return; var form=el.closest('form'); var map=L.map(el).setView([41.9028,12.4964],6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
    var m1=L.marker([41.9028,12.4964],{draggable:true}).addTo(map), m2=L.marker([41.9028,12.4964],{draggable:true}).addTo(map); var route;
    function draw(){ if(route) map.removeLayer(route); route=L.polyline([m1.getLatLng(), m2.getLatLng()],{weight:4,opacity:0.9}).addTo(map); map.fitBounds(route.getBounds(),{padding:[20,20]}); }
    m1.on('dragend',()=>{ setHidden(form,'start',m1.getLatLng()); draw(); }); m2.on('dragend',()=>{ setHidden(form,'end',m2.getLatLng()); draw(); });
    $(form).on('change','select.vcl-comune-start', function(){ var q=buildQuery(this); if(!q) return; geocodeQuery(q).then(ll=>{ if(ll){ m1.setLatLng(ll); setHidden(form,'start',ll); draw(); } }); });
    $(form).on('change','select.vcl-comune-end', function(){ var q=buildQuery(this); if(!q) return; geocodeQuery(q).then(ll=>{ if(ll){ m2.setLatLng(ll); setHidden(form,'end',ll); draw(); } }); });
    setTimeout(function(){ map.invalidateSize(); }, 300);
  }
  function initSingle(el){
    var lat=parseFloat(el.getAttribute('data-lat')), lng=parseFloat(el.getAttribute('data-lng')), lat2=parseFloat(el.getAttribute('data-lat-arr')), lng2=parseFloat(el.getAttribute('data-lng-arr'));
    if(!window.L || isNaN(lat)||isNaN(lng)) return; var map=L.map(el,{zoomControl:false,attributionControl:false}).setView([lat,lng],9);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
    var a=L.marker([lat,lng]).addTo(map); if(!isNaN(lat2)&&!isNaN(lng2)){ var b=L.marker([lat2,lng2]).addTo(map); var r=L.polyline([a.getLatLng(),b.getLatLng()],{weight:4,opacity:.9}).addTo(map); map.fitBounds(r.getBounds(),{padding:[10,10]}); }
    setTimeout(function(){ map.invalidateSize(); }, 300);
  }
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.cascade').forEach(bindCascade);
    document.querySelectorAll('.vcl-map').forEach(initDual);
    document.querySelectorAll('.vcl-map-single').forEach(initSingle);
  });
})(jQuery);
