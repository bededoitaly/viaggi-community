(function(){
  function kmFmt(x){ return (Math.round(x*10)/10).toFixed(1)+' km'; }
  function euro(x){ return '€ '+(Math.round(x*100)/100).toFixed(2); }
  function init(){
    var el=document.getElementById('vcl-scheda-map'); if(!el) return;
    var a=parseFloat(el.getAttribute('data-lat')), b=parseFloat(el.getAttribute('data-lng')), c=parseFloat(el.getAttribute('data-lat-arr')), d=parseFloat(el.getAttribute('data-lng-arr'));
    var ct=el.getAttribute('data-costo-tipo')||'gratuito', ck=parseFloat(el.getAttribute('data-costo-km')||'0.10');
    if(!window.L || isNaN(a)||isNaN(b)) return;
    var map=L.map(el,{zoomControl:true,attributionControl:false}).setView([a,b],9);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
    var m1=L.marker([a,b]).addTo(map);
    if(!isNaN(c)&&!isNaN(d)){
      var m2=L.marker([c,d]).addTo(map);
      var r=L.polyline([m1.getLatLng(),[c,d]],{weight:4,opacity:.9}).addTo(map);
      map.fitBounds(r.getBounds(),{padding:[10,10]});
      var url='https://router.project-osrm.org/route/v1/driving/'+b+','+a+';'+d+','+c+'?overview=false';
      fetch(url).then(r=>r.json()).then(j=>{
        var m=(j&&j.routes&&j.routes[0]&&j.routes[0].distance)?j.routes[0].distance:0;
        var km=m/1000;
        var distEl=document.getElementById('vcl-dist'), costEl=document.getElementById('vcl-costo');
        if(distEl) distEl.textContent=kmFmt(km);
        if(costEl){ if(ct==='km'){ costEl.textContent=euro(km*ck); } else if(ct==='fisso'){ costEl.textContent='Fisso'; } else { costEl.textContent=euro(0); } }
      }).catch(()=>{});
    }
    setTimeout(function(){ map.invalidateSize(); }, 250);
  }
  document.addEventListener('DOMContentLoaded', init);
})();