(function($){
  function play(url){ if(!url) return; try{ new Audio(url).play(); }catch(e){} }
  $(document).on('click','.vcl-btn-signal', function(){
    var t=this.getAttribute('data-type'), target=this.getAttribute('data-target'), vid=this.getAttribute('data-viaggio')||'';
    var fd=new FormData(); fd.append('action','vcl_notify'); fd.append('type',t||''); fd.append('target',target||''); fd.append('viaggio',vid);
    fetch((window.VCL_ALERT||{}).ajax||'',{method:'POST', body:fd}).then(r=>r.json()).then(function(j){
      if(j&&j.success){ play((t==='urgente')?(window.VCL_ALERT||{}).sound_urgent:(window.VCL_ALERT||{}).sound_interest); alert('Segnale inviato ✅'); }
      else{ alert('Errore invio segnale'); }
    }).catch(function(){ alert('Errore rete'); });
  });
  function startListener(box){
    var uid=box.getAttribute('data-user'), intv=parseInt(box.getAttribute('data-interval')||'7',10);
    function tick(){
      var fd=new FormData(); fd.append('action','vcl_pull_notify'); fd.append('user',uid||'');
      fetch((window.VCL_ALERT||{}).ajax||'',{method:'POST', body:fd}).then(r=>r.json()).then(function(j){
        if(j&&j.success&&j.data&&j.data.length){
          j.data.forEach(function(n){ if(n.type==='urgente'){ play((window.VCL_ALERT||{}).sound_urgent); if((window.VCL_ALERT||{}).alert_video){ window.open((window.VCL_ALERT||{}).alert_video,'_blank'); } } else { play((window.VCL_ALERT||{}).sound_interest); } });
        }
      }).catch(function(){}).finally(function(){ setTimeout(tick,intv*1000); });
    }
    setTimeout(tick,intv*1000);
  }
  document.addEventListener('DOMContentLoaded', function(){ document.querySelectorAll('.vcl-alert-listener').forEach(startListener); });
})(jQuery);
