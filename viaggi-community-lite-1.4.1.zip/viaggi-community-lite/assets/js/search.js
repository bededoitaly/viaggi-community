(function($){
  $(document).on('click','#vcl_s_submit',function(){
    var f=document.getElementById('vcl-search-form'); var fd=new FormData(); fd.append('action','vcl_search'); fd.append('nonce',(window.VCL_DATA||{}).nonce||'');
    ['s_ruolo','s_cat','s_veicolo','s_fuel'].forEach(n=>{ var el=f.querySelector('[name="'+n+'"]'); if(el) fd.append(n, el.value||''); });
    var sp=f.querySelector('select[name="s_p_com"]'); if(sp) fd.append('s_p_com', sp.value||''); var sa=f.querySelector('select[name="s_a_com"]'); if(sa) fd.append('s_a_com', sa.value||'');
    fetch((window.VCL_DATA||{}).ajax||'',{method:'POST',body:fd}).then(r=>r.json()).then(j=>{
      var box=document.getElementById('vcl-search-results'); box.innerHTML=''; if(!j||!j.success||!j.data||!j.data.items||!j.data.items.length){ box.innerHTML='<div class="box">Nessun risultato.</div>'; return; }
      j.data.items.forEach(it=>{
        var card=document.createElement('div'); card.className='vcl-card';
        card.innerHTML='<div class="top"><div><div class="title">'+(it.titolo||'Viaggio')+'</div><div class="meta">'+(it.role||'')+' • '+(it.quando||'')+' • '+(it.categoria||'')+'</div></div></div>'
          +'<div class="map-shell"><div class="vcl-map-single" data-lat="'+(it.lat||'')+'" data-lng="'+(it.lng||'')+'" data-lat-arr="'+(it.lat_arr||'')+'" data-lng-arr="'+(it.lng_arr||'')+'"></div></div>'
          +'<div class="row two"><div class="col"><strong>Da:</strong> '+(it.partenza||'')+'<br><strong>A:</strong> '+(it.arrivo||'')+'</div><div class="col right"><a class="btn" href="'+(it.link||'#')+'">Apri scheda</a></div></div>';
        box.appendChild(card);
      });
      setTimeout(function(){ document.querySelectorAll('.vcl-map-single').forEach(function(el){ var e=document.createEvent('Event'); e.initEvent('DOMContentLoaded', true, true); document.dispatchEvent(e); }); }, 30);
    }).catch(()=>alert('Errore rete'));
  });
})(jQuery);
