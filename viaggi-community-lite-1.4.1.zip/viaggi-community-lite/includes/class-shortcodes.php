<?php
if (!defined('ABSPATH')) exit;
class VCL_Shortcodes {
  public static function boot(){ add_action('init',[__CLASS__,'register']); }
  public static function register(){
    add_shortcode('vc_cascata_localita', function($atts){
      $a=shortcode_atts(array('role'=>'start','name_prefix'=>'loc','labels'=>'Regione,Provincia,Comune'),$atts,'vc_cascata_localita');
      $labels=array_map('trim', explode(',', $a['labels'])); $role=($a['role']==='end')?'vcl-comune-end':'vcl-comune-start';
      ob_start(); ?>
      <div class="cascade">
        <label><?php echo esc_html($labels[0]??'Regione'); ?></label><select class="<?php echo esc_attr($role); ?>" name="<?php echo esc_attr($a['name_prefix']); ?>_reg"></select>
        <label><?php echo esc_html($labels[1]??'Provincia'); ?></label><select class="<?php echo esc_attr($role); ?>" name="<?php echo esc_attr($a['name_prefix']); ?>_prov"></select>
        <label><?php echo esc_html($labels[2]??'Comune'); ?></label><select class="<?php echo esc_attr($role); ?>" name="<?php echo esc_attr($a['name_prefix']); ?>_com"></select>
      </div>
      <?php return ob_get_clean();
    });
    $mk=function($src,$tag){
      add_shortcode($tag,function($atts) use ($src,$tag){
        $a=shortcode_atts(array('name'=>$src,'placeholder'=>ucfirst($src),'class'=>''),$atts,$tag);
        $opts=get_option('vcl_list_'.$src,array()); ob_start(); ?>
        <select name="<?php echo esc_attr($a['name']); ?>" class="<?php echo esc_attr($a['class']); ?>">
          <option value=""><?php echo esc_html($a['placeholder']); ?></option>
          <?php foreach($opts as $o): ?><option value="<?php echo esc_attr($o); ?>"><?php echo esc_html($o); ?></option><?php endforeach; ?>
        </select><?php return ob_get_clean();
      });
    };
    $mk('veicoli','vc_select_veicolo'); $mk('fuel','vc_select_alimentazione'); $mk('ruoli','vc_select_ruolo'); $mk('categorie','vc_select_categoria'); $mk('quando','vc_select_quando');

    add_shortcode('vc_btn_interesse', function($a){ $a=shortcode_atts(array('viaggio_id'=>'','target_user'=>''),$a,'vc_btn_interesse'); return '<button class="btn vcl-btn-signal" data-type="interesse" data-viaggio="'.esc_attr($a['viaggio_id']).'" data-target="'.esc_attr($a['target_user']).'">Mi interessa il viaggio</button>'; });
    add_shortcode('vc_btn_urgente', function($a){ $a=shortcode_atts(array('viaggio_id'=>'','target_user'=>''),$a,'vc_btn_urgente'); return '<button class="btn danger vcl-btn-signal" data-type="urgente" data-viaggio="'.esc_attr($a['viaggio_id']).'" data-target="'.esc_attr($a['target_user']).'">URGENTE</button>'; });
    add_shortcode('vc_alert_listener', function($atts){ $a=shortcode_atts(array('user_id'=>'me','interval'=>'7'),$atts,'vc_alert_listener'); $uid=($a['user_id']==='me'&&is_user_logged_in())?get_current_user_id():intval($a['user_id']); if(!$uid) return '<p>Login richiesto.</p>'; return '<div class="vcl-alert-listener" data-user="'.esc_attr($uid).'" data-interval="'.esc_attr(max(3,intval($a['interval']))).'"></div>'; });

    add_shortcode('vc_form_pilota', function(){ ob_start(); ?>
      <div class="vcl-wrap"><form id="vcl-form-pilota" class="vcl-form"><input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('vcl_nonce')); ?>">
      <h2 class="vcl-title">Crea Viaggio — Pilota</h2>
      <div class="row two">
        <div class="field"><label>Titolo <span style="color:#e00">*</span></label><input type="text" name="titolo" required class="vcl-upper" minlength="3" maxlength="120" placeholder="INSERISCI TITOLO DEL VIAGGIO"></div>
        <div class="field"><label>Data & Ora</label><input type="datetime-local" name="dataora"></div>
      </div>
      <div class="row two">
        <div class="field"><label>Partenza</label><?php echo do_shortcode('[vc_cascata_localita role="start" name_prefix="part"]'); ?></div>
        <div class="field"><label>Arrivo</label><?php echo do_shortcode('[vc_cascata_localita role="end" name_prefix="arr"]'); ?></div>
      </div>
      <div class="map-shell"><div class="vcl-map" data-dual="1" data-default-lat="41.9028" data-default-lng="12.4964"></div></div>
      <input type="hidden" name="lat"><input type="hidden" name="lng"><input type="hidden" name="lat_arr"><input type="hidden" name="lng_arr">
      <div class="row two">
        <div class="field"><label>Veicolo</label><?php echo do_shortcode('[vc_select_veicolo name="veicolo" placeholder="Veicolo"]'); ?></div>
        <div class="field"><label>Alimentazione</label><?php echo do_shortcode('[vc_select_alimentazione name="fuel" placeholder="Alimentazione"]'); ?></div>
      </div>
      <div class="row two">
        <div class="field"><label>Categoria</label><?php echo do_shortcode('[vc_select_categoria name="categoria" placeholder="Categoria"]'); ?></div>
        <div class="field">
          <label>Costo</label>
          <label class="inline"><input type="radio" name="costo_tipo" value="gratuito" checked> Gratuito</label>
          <label class="inline"><input type="radio" name="costo_tipo" value="fisso"> Costo fisso</label><input type="number" name="costo_fisso" class="toggle-fisso hidden" step="0.01" min="0">
          <label class="inline"><input type="radio" name="costo_tipo" value="km"> €/km</label><select name="costo_km" class="toggle-km hidden"><?php for($i=10;$i<=200;$i+=10){ $v=number_format($i/100,2); echo '<option value="'.$v.'">'.$v.'</option>'; } ?></select>
        </div>
      </div>
      <div class="row two">
        <div class="field"><label>Posti disponibili</label><input type="number" name="posti" min="1" max="8" value="2"></div>
        <div class="field"><label>Ruolo</label><?php echo do_shortcode('[vc_select_ruolo name="ruolo" placeholder="Ruolo"]'); ?></div>
      </div>
      <div class="row two">
        <div class="field"><label>Quando</label><?php echo do_shortcode('[vc_select_quando name="quando" placeholder="Quando"]'); ?></div>
        <div class="field">&nbsp;</div>
      </div>
      <div class="row one">
        <div class="field repeat-block">
          <label class="inline"><input type="checkbox" id="vcl-ripetibile" name="ripeti" value="1"> Viaggio ripetibile</label>
          <div id="vcl-ripetizione-opzioni" class="hidden">
            <label>Giorni della settimana</label>
            <div class="vcl-days">
              <label><input type="checkbox" name="giorni[]" value="lun"> Lun</label>
              <label><input type="checkbox" name="giorni[]" value="mar"> Mar</label>
              <label><input type="checkbox" name="giorni[]" value="mer"> Mer</label>
              <label><input type="checkbox" name="giorni[]" value="gio"> Gio</label>
              <label><input type="checkbox" name="giorni[]" value="ven"> Ven</label>
              <label><input type="checkbox" name="giorni[]" value="sab"> Sab</label>
              <label><input type="checkbox" name="giorni[]" value="dom"> Dom</label>
            </div>
            <div class="row two">
              <div class="field"><label>Fine ripetibilità</label><input type="date" name="fine_ripeti"></div>
              <div class="field"><small>Se non selezioni giorni, verrà creato solo il viaggio iniziale.</small></div>
            </div>
          </div>
        </div>
      </div>
      <div class="row two"><div class="field">&nbsp;</div><div class="field"><button class="btn" id="vcl_submit_pilota">Conferma viaggio</button></div></div></form></div>
      <script>(function(){const f=document.getElementById('vcl-form-pilota'); if(!f) return;
        const $tit=f.querySelector('input[name="titolo"]'); if($tit){ $tit.addEventListener('input', ()=>{ $tit.value=($tit.value||'').toUpperCase(); }); }
        function sync(){ const t=[...f.querySelectorAll('input[name="costo_tipo"]')].find(x=>x.checked)?.value||'gratuito';
          f.querySelector('.toggle-fisso').classList.toggle('hidden', t!=='fisso'); f.querySelector('.toggle-km').classList.toggle('hidden', t!=='km'); }
        f.querySelectorAll('input[name="costo_tipo"]').forEach(r=>r.addEventListener('change',sync)); sync();
        const $chk=f.querySelector('#vcl-ripetibile'), $box=f.querySelector('#vcl-ripetizione-opzioni'); if($chk&&$box){ $chk.addEventListener('change', ()=>{ $box.classList.toggle('hidden', !$chk.checked); }); }
        document.getElementById('vcl_submit_pilota').addEventListener('click',function(e){e.preventDefault();
          if(!$tit || !$tit.value.trim()){ alert('Il TITOLO è obbligatorio.'); $tit.focus(); return; }
          const fd=new FormData(f); fd.append('action','vcl_save_pilota'); fd.append('nonce',(window.VCL_DATA||{}).nonce||'');
          ['part','arr'].forEach(p=>['reg','prov','com'].forEach(s=>{ const el=f.querySelector('select[name="'+p+'_'+s+'"]'); if(el) fd.append(p+'_'+s, el.value||''); }));
          fetch((window.VCL_DATA||{}).ajax||'',{method:'POST',body:fd}).then(r=>r.json()).then(j=>{
            try{ var url=(window.VCL_ALERT||{}).success_sound||''; if(url) new Audio(url).play(); }catch(e){}
            if(j&&j.success&&j.data&&j.data.link){ window.location.href=j.data.link; } else { alert(j&&j.data&&j.data.message?j.data.message:'Salvataggio non riuscito'); }
          }).catch(()=>alert('Errore rete'));
        });
      })();</script>
    <?php return ob_get_clean(); });
    add_shortcode('vc_form_passeggero', function(){ return do_shortcode('[vc_form_pilota]'); });

    add_shortcode('vc_ricerca_viaggi', function(){ ob_start(); ?>
      <div class="vcl-wrap"><form id="vcl-search-form" class="vcl-form" onsubmit="return false;">
      <h2 class="vcl-title">Ricerca Viaggi</h2>
      <div class="row two"><div class="field"><label>Partenza</label><?php echo do_shortcode('[vc_cascata_localita role="start" name_prefix="s_p"]'); ?></div>
      <div class="field"><label>Arrivo</label><?php echo do_shortcode('[vc_cascata_localita role="end" name_prefix="s_a"]'); ?></div></div>
      <div class="row two"><div class="field"><?php echo do_shortcode('[vc_select_ruolo name="s_ruolo" placeholder="Ruolo"]'); ?></div>
      <div class="field"><?php echo do_shortcode('[vc_select_categoria name="s_cat" placeholder="Categoria"]'); ?></div></div>
      <div class="row two"><div class="field"><?php echo do_shortcode('[vc_select_veicolo name="s_veicolo" placeholder="Veicolo"]'); ?></div>
      <div class="field"><?php echo do_shortcode('[vc_select_alimentazione name="s_fuel" placeholder="Alimentazione"]'); ?></div></div>
      <div class="actions"><button class="btn" id="vcl_s_submit">Cerca</button></div></form><div id="vcl-search-results" class="vcl-grid"></div></div>
    <?php return ob_get_clean(); });

    add_shortcode('vc_scheda_viaggio', function($atts){
      $a=shortcode_atts(array('id'=>0),$atts,'vc_scheda_viaggio'); $id=intval($a['id']); if(!$id) return '<div class="vcl-wrap"><div class="box">ID mancante</div></div>';
      $p=get_post($id); if(!$p||$p->post_type!=='vcl_viaggio') return '<div class="vcl-wrap"><div class="box">Viaggio non trovato</div></div>';
      $M=function($k,$d='') use($id){ return get_post_meta($id,'_vcl_'.$k,true) ?: $d; };
      $author=$p->post_author; $nickname=get_the_author_meta('nickname',$author); $nome=get_the_author_meta('first_name',$author); $cognome=get_the_author_meta('last_name',$author); $email=get_the_author_meta('user_email',$author); $tel=get_user_meta($author,'phone',true); $avatar=get_avatar_url($author,array('size'=>128));
      $titolo=get_the_title($id); $dataora=$M('dataora','');
      ob_start(); ?>
      <div class="vcl-wrap">
        <div class="vcl-scheda">
          <div class="head">
            <div><h2 class="title"><?php echo esc_html($titolo); ?></h2><div class="sub"><?php echo esc_html($dataora ? date_i18n('d/m/Y H:i', strtotime($dataora)) : 'Data da definire'); ?> • ID #<?php echo $id; ?></div></div>
            <div class="actions">
              <a class="btn" href="<?php echo esc_url(add_query_arg('vcl_pdf',$id, home_url('/'))); ?>" target="_blank">Stampa / PDF</a>
              <?php if(is_user_logged_in()){ echo do_shortcode('[vc_btn_interesse viaggio_id="'.$id.'" target_user="'.$author.'"]'); echo ' '; echo do_shortcode('[vc_btn_urgente viaggio_id="'.$id.'" target_user="'.$author.'"]'); } ?>
            </div>
          </div>
          <div class="grid">
            <div class="col">
              <div class="box">
                <div class="row two"><div><strong>Partenza</strong><br><?php echo esc_html($M('part_com')); ?></div><div><strong>Arrivo</strong><br><?php echo esc_html($M('arr_com')); ?></div></div>
                <div class="row two"><div><strong>Ruolo</strong><br><?php echo esc_html($M('ruolo')); ?></div><div><strong>Categoria</strong><br><?php echo esc_html($M('categoria')); ?></div></div>
                <div class="row two"><div><strong>Veicolo</strong><br><?php echo esc_html($M('veicolo')); ?></div><div><strong>Alimentazione</strong><br><?php echo esc_html($M('fuel')); ?></div></div>
                <div class="row two">
                  <div><strong>Posti</strong><br><?php echo esc_html($M('posti','2')); ?></div>
                  <div><strong>Costo</strong><br><?php $ct=$M('costo_tipo','gratuito'); if($ct==='fisso') echo 'Fisso € '.esc_html($M('costo_fisso','0.00')); elseif($ct==='km') echo '€ / km '.esc_html($M('costo_km','0.10')); else echo 'Gratuito'; ?></div>
                </div>
              </div>
              <div class="box">
                <div id="vcl-scheda-map" class="vcl-map-single"
                  data-lat="<?php echo esc_attr($M('lat')); ?>"
                  data-lng="<?php echo esc_attr($M('lng')); ?>"
                  data-lat-arr="<?php echo esc_attr($M('lat_arr')); ?>"
                  data-lng-arr="<?php echo esc_attr($M('lng_arr')); ?>"
                  data-costo-tipo="<?php echo esc_attr($M('costo_tipo','gratuito')); ?>"
                  data-costo-km="<?php echo esc_attr($M('costo_km','0.10')); ?>"
                  style="width:100%;height:270px"></div>
                <div class="row two metrics"><div><strong>Distanza</strong><br><span id="vcl-dist">—</span></div><div><strong>Stima costo</strong><br><span id="vcl-costo">—</span></div></div>
              </div>
            </div>
            <div class="col">
              <div class="box profile">
                <div class="avatar" style="background-image:url('<?php echo esc_url($avatar); ?>')"></div>
                <div class="who"><div class="nick"><?php echo esc_html($nickname ?: 'Utente'); ?></div><div class="name"><?php echo esc_html(trim($nome.' '.$cognome)); ?></div>
                  <div class="contact"><?php if($tel): ?><div>Tel/WhatsApp: <?php echo esc_html($tel); ?></div><?php endif; ?><div>Email: <?php echo esc_html($email); ?></div></div>
                </div>
              </div>
              <div class="box smalltext"><p>Premi “Mi interessa il viaggio” per notificare subito l’autore. In caso di necessità usa “URGENTE”.</p></div>
            </div>
          </div>
        </div>
      </div>
      <?php return ob_get_clean();
    });

    add_shortcode('vc_report_viaggio', function($atts){ $a=shortcode_atts(array('id'=>0),$atts,'vc_report_viaggio'); return do_shortcode('[vc_scheda_viaggio id="'.$a['id'].'"]'); });

    add_shortcode('vc_super_mappa', function($atts){
      $a=shortcode_atts(array('altezza'=>'420','limite'=>'200'),$atts,'vc_super_mappa'); ob_start(); ?>
      <div class="vcl-wrap vcl-super-wrap">
        <form class="vcl-form" id="vcl-super-filters" onsubmit="return false;">
          <div class="row two"><div class="field"><?php echo do_shortcode('[vc_select_ruolo name="s_ruolo" placeholder="Ruolo"]'); ?></div><div class="field"><?php echo do_shortcode('[vc_select_categoria name="s_cat" placeholder="Categoria"]'); ?></div></div>
          <div class="row two"><div class="field"><?php echo do_shortcode('[vc_select_veicolo name="s_veicolo" placeholder="Veicolo"]'); ?></div><div class="field"><?php echo do_shortcode('[vc_select_alimentazione name="s_fuel" placeholder="Alimentazione"]'); ?></div></div>
          <div class="row two"><div class="field"><label>Comune partenza</label><?php echo do_shortcode('[vc_cascata_localita role="start" name_prefix="s_p"]'); ?></div><div class="field"><label>Comune arrivo</label><?php echo do_shortcode('[vc_cascata_localita role="end" name_prefix="s_a"]'); ?></div></div>
          <div class="actions"><button class="btn" id="vcl-super-apply">Applica filtri</button></div>
        </form>
        <div class="map-shell" style="height:<?php echo intval($a['altezza']); ?>px"><div class="vcl-supermap" data-limit="<?php echo intval($a['limite']); ?>" style="width:100%;height:100%"></div></div>
      </div>
      <?php return ob_get_clean();
    });
  }
}
VCL_Shortcodes::boot();
