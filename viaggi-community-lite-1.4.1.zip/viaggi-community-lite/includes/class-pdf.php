<?php
if (!defined('ABSPATH')) exit;
class VCL_PDF {
  public static function boot(){ add_action('init',[__CLASS__,'route']); }
  public static function route(){
    if(isset($_GET['vcl_pdf'])){
      $id=intval($_GET['vcl_pdf']); $p=get_post($id); if(!$p||$p->post_type!=='vcl_viaggio'){ status_header(404); exit('Not found'); }
      $M=function($k,$d='') use($id){ return get_post_meta($id,'_vcl_'.$k,true) ?: $d; };
      $titolo=get_the_title($id); $dataora=$M('dataora',''); $author=$p->post_author; $avatar=get_avatar_url($author,array('size'=>96));
      header('Content-Type:text/html; charset=UTF-8'); ?><!doctype html><html><head><meta charset="utf-8"><title>Report Viaggio #<?php echo $id; ?></title>
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
      <style>body{font-family:system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#fff;color:#111;margin:0;padding:24px;}
      h1{margin:0 0 6px;font-size:20px}.meta{color:#555;margin-bottom:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
      .box{border:1px solid #ddd;border-radius:10px;padding:12px}#mappa{width:100%;height:280px;border:1px solid #ddd;border-radius:10px;margin-top:8px}
      .print{margin:10px 0}@media print{ .print{display:none} }</style></head><body>
      <h1><?php echo esc_html($titolo); ?></h1>
      <div class="meta">ID #<?php echo $id; ?> • <?php echo esc_html($dataora ? date_i18n('d/m/Y H:i', strtotime($dataora)) : 'Data da definire'); ?></div>
      <div class="grid"><div class="box">
      <strong>Partenza</strong>: <?php echo esc_html($M('part_com')); ?><br>
      <strong>Arrivo</strong>: <?php echo esc_html($M('arr_com')); ?><br>
      <strong>Veicolo</strong>: <?php echo esc_html($M('veicolo')); ?> • <?php echo esc_html($M('fuel')); ?><br>
      <strong>Posti</strong>: <?php echo esc_html($M('posti','2')); ?><br>
      <strong>Costo</strong>: <?php $ct=$M('costo_tipo','gratuito'); if($ct==='fisso'){ echo 'Fisso € '.esc_html($M('costo_fisso','0.00')); } elseif($ct==='km'){ echo '€ / km '.esc_html($M('costo_km','0.10')); } else { echo 'Gratuito'; } ?>
      </div><div class="box"><div><img src="<?php echo esc_url($avatar); ?>" style="width:48px;height:48px;border-radius:50%;vertical-align:middle;margin-right:8px"> Autore: <?php echo esc_html(get_the_author_meta('display_name',$author)); ?></div>
      <div id="metrics" style="margin-top:8px"><strong>Distanza</strong>: <span id="km">—</span> • <strong>Stima costo</strong>: <span id="costo">—</span></div></div></div>
      <div id="mappa" data-lat="<?php echo esc_attr($M('lat')); ?>" data-lng="<?php echo esc_attr($M('lng')); ?>" data-lat-arr="<?php echo esc_attr($M('lat_arr')); ?>" data-lng-arr="<?php echo esc_attr($M('lng_arr')); ?>" data-ct="<?php echo esc_attr($M('costo_tipo','gratuito')); ?>" data-ck="<?php echo esc_attr($M('costo_km','0.10')); ?>"></div>
      <div class="print"><button onclick="window.print()">Stampa</button></div>
      <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
      <script>(function(){var el=document.getElementById('mappa');
        var a=parseFloat(el.getAttribute('data-lat')), b=parseFloat(el.getAttribute('data-lng')), c=parseFloat(el.getAttribute('data-lat-arr')), d=parseFloat(el.getAttribute('data-lng-arr'));
        var ct=el.getAttribute('data-ct')||'gratuito', ck=parseFloat(el.getAttribute('data-ck')||'0.10');
        if(!isNaN(a)&&!isNaN(b)){ var map=L.map('mappa').setView([a,b],8);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
          var m1=L.marker([a,b]).addTo(map);
          if(!isNaN(c)&&!isNaN(d)){ var m2=L.marker([c,d]).addTo(map); var r=L.polyline([m1.getLatLng(), m2.getLatLng()],{weight:4,opacity:.9}).addTo(map); map.fitBounds(r.getBounds(),{padding:[10,10]});
            var url='https://router.project-osrm.org/route/v1/driving/'+b+','+a+';'+d+','+c+'?overview=false';
            fetch(url).then(r=>r.json()).then(j=>{ var m=(j&&j.routes&&j.routes[0]&&j.routes[0].distance)?j.routes[0].distance:0; var km=m/1000; document.getElementById('km').textContent=km.toFixed(1)+' km';
              var est='—'; if(ct==='km'){ est='€ '+(km*ck).toFixed(2); } else if(ct==='fisso'){ est='(fisso)'; } else { est='€ 0,00'; } document.getElementById('costo').textContent=est; }).catch(()=>{});
          } setTimeout(function(){ map.invalidateSize(); }, 200); } })();</script></body></html><?php
      exit;
    }
  }
}
VCL_PDF::boot();
