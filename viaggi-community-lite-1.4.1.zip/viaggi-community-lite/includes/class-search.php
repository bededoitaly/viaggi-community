<?php
if (!defined('ABSPATH')) exit;
class VCL_Search {
  public static function ajax(){
    check_ajax_referer('vcl_nonce','nonce');
    $args=array('post_type'=>'vcl_viaggio','post_status'=>'publish','posts_per_page'=>200,'orderby'=>'date','order'=>'DESC','meta_query'=>array('relation'=>'AND'));
    $filters=array('s_ruolo'=>'_vcl_ruolo','s_cat'=>'_vcl_categoria','s_veicolo'=>'_vcl_veicolo','s_fuel'=>'_vcl_fuel');
    foreach($filters as $req=>$meta){ if(!empty($_POST[$req])) $args['meta_query'][]=array('key'=>$meta,'value'=>sanitize_text_field($_POST[$req]),'compare'=>'='); }
    if(!empty($_POST['s_p_com'])) $args['meta_query'][]=array('key'=>'_vcl_part_com','value'=>sanitize_text_field($_POST['s_p_com']),'compare'=>'=');
    if(!empty($_POST['s_a_com'])) $args['meta_query'][]=array('key'=>'_vcl_arr_com','value'=>sanitize_text_field($_POST['s_a_com']),'compare'=>'=');
    $q=new WP_Query($args); $items=array();
    foreach($q->posts as $p){ $id=$p->ID;
      $items[]=array('id'=>$id,'titolo'=>get_the_title($id),'link'=>get_permalink($id),
        'role'=>get_post_meta($id,'_vcl_ruolo',true),'quando'=>get_post_meta($id,'_vcl_quando',true),'categoria'=>get_post_meta($id,'_vcl_categoria',true),
        'partenza'=>get_post_meta($id,'_vcl_part_com',true),'arrivo'=>get_post_meta($id,'_vcl_arr_com',true),
        'lat'=>(float)get_post_meta($id,'_vcl_lat',true),'lng'=>(float)get_post_meta($id,'_vcl_lng',true),
        'lat_arr'=>(float)get_post_meta($id,'_vcl_lat_arr',true),'lng_arr'=>(float)get_post_meta($id,'_vcl_lng_arr',true),
        'costo_tipo'=>get_post_meta($id,'_vcl_costo_tipo',true),'costo_fisso'=>get_post_meta($id,'_vcl_costo_fisso',true),'costo_km'=>get_post_meta($id,'_vcl_costo_km',true),
        'posti'=>get_post_meta($id,'_vcl_posti',true) );
    }
    wp_send_json_success(array('items'=>$items));
  }
}