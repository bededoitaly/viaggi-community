<?php
if (!defined('ABSPATH')) exit;
class VCL_Admin {
  public static function boot(){ add_action('admin_menu',[__CLASS__,'menu']); add_action('admin_enqueue_scripts', function(){ wp_enqueue_media(); }); }
  public static function menu(){
    add_menu_page('Viaggi LITE','Viaggi LITE','manage_options','vcl',[__CLASS__,'settings'],'dashicons-location',26);
    add_submenu_page('vcl','Dati (CSV)','Dati (CSV)','manage_options','vcl-dati',[__CLASS__,'data']);
  }
  public static function settings(){
    if(!current_user_can('manage_options')) return;
    if(!empty($_POST['vcl_save']) && check_admin_referer('vcl_settings')){
      update_option('vcl_landing', esc_url_raw($_POST['vcl_landing'] ?? ''));
      update_option('vcl_success_sound', esc_url_raw($_POST['vcl_success_sound'] ?? ''));
      update_option('vcl_interest_sound', esc_url_raw($_POST['vcl_interest_sound'] ?? ''));
      update_option('vcl_urgent_sound', esc_url_raw($_POST['vcl_urgent_sound'] ?? ''));
      update_option('vcl_alert_video', esc_url_raw($_POST['vcl_alert_video'] ?? ''));
      echo '<div class="notice notice-success"><p>Salvato ✅</p></div>';
    }
    $landing = esc_url(get_option('vcl_landing','https://dammiunpassaggio.it/dove-ti-porto'));
    $sound_ok = esc_url(get_option('vcl_success_sound', VCL_URL.'assets/audio/success.mp3'));
    $sound_interest = esc_url(get_option('vcl_interest_sound', $sound_ok));
    $sound_urgent = esc_url(get_option('vcl_urgent_sound', $sound_ok));
    $video_url = esc_url(get_option('vcl_alert_video', ''));
    echo '<div class="wrap"><h1>Viaggi LITE — Impostazioni</h1><form method="post">';
    wp_nonce_field('vcl_settings');
    echo '<table class="form-table">
      <tr><th>Pagina di atterraggio</th><td><input type="url" name="vcl_landing" style="width:420px" value="'.$landing.'"></td></tr>
      <tr><th>Suono conferma (MP3)</th>
        <td><input id="vcl_success_sound" type="url" name="vcl_success_sound" style="width:420px" value="'.$sound_ok.'">
        <button type="button" class="button" onclick="vclPickMedia(\'vcl_success_sound\')">Scegli da Media</button>
        <button type="button" class="button" onclick="new Audio(document.getElementById(\'vcl_success_sound\').value).play()">Test</button>
      </td></tr>
      <tr><th>Suono “Mi interessa” (MP3)</th>
        <td><input id="vcl_interest_sound" type="url" name="vcl_interest_sound" style="width:420px" value="'.$sound_interest.'">
        <button type="button" class="button" onclick="vclPickMedia(\'vcl_interest_sound\')">Scegli da Media</button>
        <button type="button" class="button" onclick="new Audio(document.getElementById(\'vcl_interest_sound\').value).play()">Test</button>
      </td></tr>
      <tr><th>Suono “URGENTE” (MP3)</th>
        <td><input id="vcl_urgent_sound" type="url" name="vcl_urgent_sound" style="width:420px" value="'.$sound_urgent.'">
        <button type="button" class="button" onclick="vclPickMedia(\'vcl_urgent_sound\')">Scegli da Media</button>
        <button type="button" class="button" onclick="new Audio(document.getElementById(\'vcl_urgent_sound\').value).play()">Test</button>
      </td></tr>
      <tr><th>Video allerta (MP4 opz.)</th><td><input id="vcl_alert_video" type="url" name="vcl_alert_video" style="width:420px" value="'.$video_url.'"></td></tr>
    </table><p><button class="button button-primary" name="vcl_save" value="1">Salva</button></p></form></div>';
    echo '<script>(function(){ if (!window.wp || !wp.media) return; window.vclPickMedia=function(id){ const f=wp.media({title:"Seleziona",button:{text:"Usa"},multiple:false}); f.on("select",function(){ const j=f.state().get("selection").first().toJSON(); if(j&&j.url) document.getElementById(id).value=j.url; }); f.open(); }; })();</script>';
  }
  public static function data(){
    if(!current_user_can('manage_options')) return;
    if(!empty($_POST['vcl_save_tree']) && check_admin_referer('vcl_dati')){
      $csv = isset($_POST['vcl_tree_csv']) ? wp_unslash($_POST['vcl_tree_csv']) : '';
      if(!empty($_FILES['vcl_tree_file']['tmp_name'])){ $csv = file_get_contents($_FILES['vcl_tree_file']['tmp_name']); }
      $tree=array(); if($csv){ $lines=preg_split('/\r\n|\r|\n/',$csv); foreach($lines as $line){ $line=trim($line); if($line==='') continue;
        $parts=preg_split('/[,;]+/',$line); if(count($parts)<3) continue;
        $reg=trim($parts[0]); $prov=trim($parts[1]); $com=trim(' '.implode(' ', array_slice($parts,2)));
        if(!isset($tree[$reg])) $tree[$reg]=array(); if(!isset($tree[$reg][$prov])) $tree[$reg][$prov]=array();
        if(!in_array($com,$tree[$reg][$prov],true)) $tree[$reg][$prov][]=$com;
      } }
      update_option('vcl_tree', $tree); update_option('vcl_tree_csv_raw', $csv);
      echo '<div class="notice notice-success"><p>Località aggiornate ('.count($tree).' regioni).</p></div>';
    }
    if(!empty($_POST['vcl_save_lists']) && check_admin_referer('vcl_dati')){
      $toList=function($txt){ $arr=array(); $lines=preg_split('/\r\n|\r|\n/', wp_unslash($txt)); foreach($lines as $line){ $v=trim(preg_replace('/[;,\t]+/',' ', $line)); if($v!=='') $arr[]=$v; } $arr=array_values(array_unique($arr)); sort($arr,SORT_NATURAL|SORT_FLAG_CASE); return $arr; };
      update_option('vcl_list_categorie', $toList($_POST['vcl_list_categorie']??''));
      update_option('vcl_list_veicoli',   $toList($_POST['vcl_list_veicoli']??''));
      update_option('vcl_list_fuel',      $toList($_POST['vcl_list_fuel']??''));
      update_option('vcl_list_ruoli',     $toList($_POST['vcl_list_ruoli']??''));
      update_option('vcl_list_quando',    $toList($_POST['vcl_list_quando']??''));
      echo '<div class="notice notice-success"><p>Liste aggiornate.</p></div>';
    }
    $csv_raw = get_option('vcl_tree_csv_raw','');
    $lists = array(
      'categorie' => implode("\n", get_option('vcl_list_categorie', array('Lavoro','Studio','Turismo'))),
      'veicoli'   => implode("\n", get_option('vcl_list_veicoli', array('Auto','Furgone','Camion','Camper','Moto'))),
      'fuel'      => implode("\n", get_option('vcl_list_fuel', array('Benzina','Diesel','GPL','Metano','Elettrico','Ibrido'))),
      'ruoli'     => implode("\n", get_option('vcl_list_ruoli', array('Pilota','Passeggero'))),
      'quando'    => implode("\n", get_option('vcl_list_quando', array('Subito','Quanto prima','Data specifica'))),
    );
    echo '<div class="wrap"><h1>Viaggi LITE — Dati (CSV)</h1>';
    echo '<h2 class="nav-tab-wrapper"><a href="#tab_tree" class="nav-tab nav-tab-active" onclick="vclTab(event,\'tab_tree\')">Località</a><a href="#tab_lists" class="nav-tab" onclick="vclTab(event,\'tab_lists\')">Liste</a></h2>';
    echo '<div id="tab_tree" class="vcl-tab active"><form method="post" enctype="multipart/form-data">';
    wp_nonce_field('vcl_dati');
    echo '<p>Incolla righe <code>Regione,Provincia,Comune</code> (oppure carica CSV). Separatori: <code>,</code> o <code>;</code>.</p><p><input type="file" name="vcl_tree_file" accept=".csv,text/csv"></p>';
    echo '<p><textarea name="vcl_tree_csv" style="width:100%;height:220px" placeholder="Sicilia,Catania,San Gregorio di Catania&#10;Sicilia,Catania,San Michele di Ganzaria">'.esc_textarea($csv_raw).'</textarea></p>';
    echo '<p><button class="button button-primary" name="vcl_save_tree" value="1">Salva Località</button></p></form></div>';
    echo '<div id="tab_lists" class="vcl-tab" style="display:none"><form method="post">';
    wp_nonce_field('vcl_dati');
    echo '<table class="form-table">
      <tr><th>Categorie viaggio</th><td><textarea name="vcl_list_categorie" style="width:520px;height:120px">'.esc_textarea($lists['categorie']).'</textarea></td></tr>
      <tr><th>Veicoli</th><td><textarea name="vcl_list_veicoli" style="width:520px;height:120px">'.esc_textarea($lists['veicoli']).'</textarea></td></tr>
      <tr><th>Alimentazioni</th><td><textarea name="vcl_list_fuel" style="width:520px;height:120px">'.esc_textarea($lists['fuel']).'</textarea></td></tr>
      <tr><th>Ruoli</th><td><textarea name="vcl_list_ruoli" style="width:520px;height:120px">'.esc_textarea($lists['ruoli']).'</textarea></td></tr>
      <tr><th>Quando</th><td><textarea name="vcl_list_quando" style="width:520px;height:120px">'.esc_textarea($lists['quando']).'</textarea></td></tr>
    </table><p><button class="button button-primary" name="vcl_save_lists" value="1">Salva Liste</button></p></form></div>';
    echo '</div><script>function vclTab(e,id){e.preventDefault();document.querySelectorAll(\'.nav-tab\').forEach(x=>x.classList.remove(\'nav-tab-active\'));e.target.classList.add(\'nav-tab-active\');document.querySelectorAll(\'.vcl-tab\').forEach(x=>x.style.display=\'none\');document.getElementById(id).style.display=\'block\');}</script>';
  }
}
VCL_Admin::boot();
