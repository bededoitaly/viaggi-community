<?php
if (!defined('ABSPATH')) exit;
class VCL_CPT {
  public static function boot(){ add_action('init',[__CLASS__,'register']); }
  public static function register(){
    register_post_type('vcl_viaggio', array(
      'label'=>'Viaggi','public'=>true,'show_in_menu'=>'vcl','supports'=>array('title','thumbnail','author'),
      'has_archive'=>true,'rewrite'=>array('slug'=>'viaggi'),'menu_icon'=>'dashicons-location-alt'
    ));
  }
}
VCL_CPT::boot();
