<?php
if (!defined('ABSPATH')) exit;
class VCL_API {
  private static function t($v){ return sanitize_text_field($v ?? ''); }
  private static function f($v){ return is_numeric($v) ? floatval($v) : ''; }
  private static function normalize_title($title){ $title=trim((string)$title); if($title==='') return $title; return function_exists('mb_strtoupper')?mb_strtoupper($title,'UTF-8'):strtoupper($title); }
  private static function insert_viaggio($title,$meta){
    $post_id=wp_insert_post(array('post_type'=>'vcl_viaggio','post_title'=>$title,'post_status'=>'publish','post_author'=>get_current_user_id()?:0),true);
    if(is_wp_error($post_id)) return $post_id;
    foreach($meta as $k=>$v){ update_post_meta($post_id,'_vcl_'.$k,$v); } return $post_id;
  }
  private static function save_common($data){
    $title=isset($data['titolo'])?self::t($data['titolo']):''; $title=preg_replace('/\s+/u',' ',trim($title));
    if($title==='') return new WP_Error('vcl_required','Il titolo è obbligatorio.'); $title=self::normalize_title($title);
    $fields=array('dataora','categoria','veicolo','fuel','tappe','ripeti','fine_ripeti','costo_tipo','costo_fisso','costo_km','part_reg','part_prov','part_com','arr_reg','arr_prov','arr_com','lat','lng','lat_arr','lng_arr','ruolo','quando','posti');
    $meta=array(); foreach($fields as $f){ $val=isset($data[$f])?$data[$f]:''; $val=in_array($f,array('lat','lng','lat_arr','lng_arr','costo_fisso','costo_km','posti'))?self::f($val):self::t($val); $meta[$f]=$val; }
    $is_repeat=!empty($data['ripeti']) && !empty($data['fine_ripeti']); $created=array();
    if($is_repeat){
      $base=!empty($data['dataora'])?self::t($data['dataora']):''; try{$start=new DateTime($base);}catch(Exception $e){$start=new DateTime();}
      try{$end=new DateTime(self::t($data['fine_ripeti']).' 23:59:59');}catch(Exception $e){$end=clone $start;}
      $giorni=isset($data['giorni'])?(array)$data['giorni']:array(); $map=array('lun'=>1,'mar'=>2,'mer'=>3,'gio'=>4,'ven'=>5,'sab'=>6,'dom'=>7);
      $wanted=array(); foreach($giorni as $g){ $g=self::t($g); if(isset($map[$g])) $wanted[]=$map[$g]; } $wanted=array_unique(array_values($wanted));
      if(empty($wanted)){ $pid=self::insert_viaggio($title,$meta); if(is_wp_error($pid)) return $pid; $created[]=$pid; }
      else { $cur=clone $start; $guard=0; while($cur<=$end && $guard<365){ $dow=(int)$cur->format('N'); if(in_array($dow,$wanted,true)){ $meta_i=$meta; $meta_i['dataora']=$cur->format('Y-m-d H:i:s'); $pid=self::insert_viaggio($title,$meta_i); if(!is_wp_error($pid)) $created[]=$pid; } $cur->modify('+1 day'); $guard++; } }
      if(!empty($created)) return array('first_id'=>$created[0],'all_ids'=>$created); else return new WP_Error('vcl_create','Nessun viaggio creato.');
    } else { $pid=self::insert_viaggio($title,$meta); if(is_wp_error($pid)) return $pid; return array('first_id'=>$pid,'all_ids'=>array($pid)); }
  }
  public static function save_pilota(){ check_ajax_referer('vcl_nonce','nonce'); $r=self::save_common($_POST); if(is_wp_error($r)) wp_send_json_error(array('message'=>$r->get_error_message())); wp_send_json_success(array('id'=>$r['first_id'],'link'=>get_permalink($r['first_id']),'created'=>count($r['all_ids']))); }
  public static function save_passegero_proxy(){ self::save_pilota(); }
}